package `in`.starbow.fitindia
class model (val title:String,val description:String, val img:Int){


}
# FitIndia
Hackthon Project
https://drive.google.com/file/d/1hW04EAhE-KX22kfOCHv4GKkwypN2evcR/view

# Technology/language/tools Used 
 - firebase 
 - kotlin
 - java
 - android studio

# Screenshots

![](Screenshots/ss51.jpeg)

![](Screenshots/ss62.jpeg)

![](Screenshots/ss13.jpeg)

![](Screenshots/ss44.jpeg)

![](Screenshots/ss35.jpeg)

![](Screenshots/ss26.jpeg)
